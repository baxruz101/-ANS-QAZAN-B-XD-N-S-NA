
# Şans Qazan — Hazır Veb Paketi

Bu paket GitHub Pages və ya hər hansı statik hostda yerləşdirməyə hazır bir veb oyunudur.

**Daxildə:**
- index.html — oyun səhifəsi (HTML/CSS/JS)
- README.md — bu fayl

---

## Quraşdırma (GitHub Pages üçün qısa)
1. GitHub-da yeni *public* repository yaradın (məsələn `sans-qazan`).
2. Bu ZIP fayldakı `index.html` faylını repoya yükləyin (Upload files → commit).
3. Repository → Settings → Pages bölməsindən **Branch: main, folder: / (root)** seçin və Deploy edin.
4. Bir neçə dəqiqədən sonra sayt aktiv olacaq: `https://<istifadəci-adı>.github.io/<repo-adı>/`

---

## Reklam əlavə etmə
- `index.html` faylında sağ tərəfdə `ad-slot` div yerləşir (`id="ad1"`).
- Google AdSense və ya digər şəbəkənin JS kodunu həmin bölməyə əlavə edin.
- AdSense-də saytınızı qeyd edərkən domen yoxlanışı tələb olunur.

**Qeyd:** AdSense və digər reklam şəbəkələrinin siyasətlərinə əməl edin. Reklam kodunu əlavə etdikdən sonra dəyişiklikləri `commit` edib yenidən yerləşdirin.

---

## Monetizasiya tələbləri və tövsiyə
- İlk mərhələdə reklam + `BuyMeACoffee` / sponsor linkləri istifadə edin.
- Əgər real pul çıxarışı və ya "oyna və qazan" sistemi qurmaq istəyirsinizsə, sizə backend, istifadəçi doğrulama, ödəniş provayderləri (Stripe/PayPal) və hüquqi məsləhət lazımdır.

---

## Dəstək
Mənimlə yenidən əlaqə saxlayın, əgər istəyirsinizsə mən bu paketi sizin üçün birbaşa GitHub repository-yə yükləyim və ya Netlify ilə deploy edim.

Paket yaradılma tarixi: 2025-10-21T09:45:48.688119 UTC
